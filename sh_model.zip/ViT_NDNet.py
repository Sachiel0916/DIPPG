from PIL import Image
import numpy as np
import argparse
import random
import tqdm
import xlrd
import xlwt
import os

import torch
from torch import nn
from torch.nn import functional as F
from torch.utils import data
# from torch.utils.data.dataset import T_co
from torchvision import transforms

from einops import rearrange
from timm.models.layers import DropPath, to_2tuple, trunc_normal_


def window_partition(x, window_size):
    b, t, s, c = x.shape
    x = x.view(b, t // window_size, window_size, s // window_size, window_size, c)
    windows = x.permute(0, 1, 3, 2, 4, 5).contiguous().view(-1, window_size, window_size, c)
    return windows


def window_reverse(windows, window_size, t, s):
    b = int(windows.shape[0] / (t * s / window_size / window_size))
    x = windows.view(b, t // window_size, s // window_size, window_size, window_size, -1)
    x = x.permute(0, 1, 3, 2, 4, 5).contiguous().view(b, t, s, -1)
    return x


class PatchEmbed(nn.Module):
    def __init__(self, in_chans, embed_dim):
        super(PatchEmbed, self).__init__()
        self.proj = nn.Conv2d(in_chans, embed_dim, kernel_size=(1, 5), stride=(1, 1), padding=(0, 2))
        self.norm = nn.LayerNorm(embed_dim)

    def forward(self, x):
        b, c, t, s = x.shape                            # b, 3, 320, 64
        x = self.proj(x)                                # b, 96, 320, 64
        x = x.flatten(2).transpose(1, 2).contiguous()   # b, 320*64, 96
        x = self.norm(x)                                # b, 320*64, 96
        return x


class PatchMergingSpatioTemporal(nn.Module):
    def __init__(self, dim, input_resolution):
        super(PatchMergingSpatioTemporal, self).__init__()
        self.input_resolution = input_resolution
        self.norm = nn.LayerNorm(4 * dim)
        self.reduction = nn.Linear(4 * dim, 2 * dim, bias=False)

    def forward(self, x):
        t, s = self.input_resolution
        b, f, c = x.shape
        assert f == t * s

        x = x.view(b, t, s, c)

        x0 = x[:, 0::2, 0::2, :]    # b, t/2, s/2, c
        x1 = x[:, 1::2, 0::2, :]    # b, t/2, s/2, c
        x2 = x[:, 0::2, 1::2, :]    # b, t/2, s/2, c
        x3 = x[:, 1::2, 1::2, :]    # b, t/2, s/2, c
        x = torch.cat([x0, x1, x2, x3], -1)
        x = x.view(b, -1, 4 * c)

        x = self.norm(x)
        x = self.reduction(x)
        return x


class PatchMergingSpatial(nn.Module):
    def __init__(self, dim, input_resolution):
        super(PatchMergingSpatial, self).__init__()
        self.input_resolution = input_resolution
        self.norm = nn.LayerNorm(2 * dim)
        self.reduction = nn.Linear(2 * dim, 2 * dim, bias=False)

    def forward(self, x):
        t, s = self.input_resolution
        b, f, c = x.shape
        assert f == t * s

        x = x.view(b, t, s, c)
        x0 = x[:, :, 0::2, :]
        x1 = x[:, :, 1::2, :]
        x = torch.cat([x0, x1], -1)
        x = x.view(b, -1, 2 * c)

        x = self.norm(x)
        x = self.reduction(x)
        return x


class PatchExpandSpatioTemporal(nn.Module):
    def __init__(self, dim, input_resolution):
        super(PatchExpandSpatioTemporal, self).__init__()
        self.dim = dim
        self.input_resolution = input_resolution
        self.expand = nn.Linear(dim, 2 * dim, bias=False)
        self.norm = nn.LayerNorm(dim // 2)

    def forward(self, x):
        t, s = self.input_resolution
        x = self.expand(x)
        b, f, c = x.shape
        assert f == t * s

        x = x.view(b, t, s, c)
        x = rearrange(x, 'b t s (p1 p2 c0) -> b (t p1) (s p2) c0', p1=2, p2=2, c0=c // 4)
        x = x.view(b, -1, c // 4)
        x = self.norm(x)
        return x


class PatchExpandSpatial(nn.Module):
    def __init__(self, dim, input_resolution):
        super(PatchExpandSpatial, self).__init__()
        self.dim = dim
        self.input_resolution = input_resolution
        self.expand = nn.Identity()
        self.norm = nn.LayerNorm(dim // 2)

    def forward(self, x):
        t, s = self.input_resolution
        x = self.expand(x)
        b, f, c = x.shape
        assert f == t * s

        x = x.view(b, t, s, c)
        x = rearrange(x, 'b t s (p0 c0) -> b t (s p0) c0', p0=2, c0=c // 2)
        x = x.view(b, -1, c // 2)
        x = self.norm(x)
        return x


class Mlp(nn.Module):
    def __init__(self, in_features, hidden_features,
                 out_features=None, drop_rate=0.):
        super(Mlp, self).__init__()
        out_features = out_features or in_features

        self.fc1 = nn.Linear(in_features, hidden_features)
        self.act = nn.GELU()
        self.fc2 = nn.Linear(hidden_features, out_features)
        self.drop = nn.Dropout(drop_rate)

    def forward(self, x):
        x = self.fc1(x)
        x = self.act(x)
        x = self.drop(x)
        x = self.fc2(x)
        x = self.drop(x)
        return x


class WindowAttention(nn.Module):
    def __init__(self, dim, window_size, num_heads,
                 qk_scale=None, qkv_bias=True, attn_drop_rate=0., proj_drop_rate=0.):
        super(WindowAttention, self).__init__()
        self.dim = dim
        self.window_size = window_size
        self.num_heads = num_heads
        head_dim = dim // num_heads
        self.scale = qk_scale or head_dim ** -0.5

        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)

        self.relative_position_bias_table = nn.Parameter(
            torch.zeros((2 * window_size[0] - 1) * (2 * window_size[1] - 1), num_heads))

        coords_t = torch.arange(self.window_size[0])
        coords_s = torch.arange(self.window_size[1])
        coords = torch.stack(torch.meshgrid([coords_t, coords_s]))
        coords_flatten = torch.flatten(coords, 1)
        relative_coords = coords_flatten[:, :, None] - coords_flatten[:, None, :]
        relative_coords = relative_coords.permute(1, 2, 0).contiguous()
        relative_coords[:, :, 0] += self.window_size[0] - 1
        relative_coords[:, :, 1] += self.window_size[1] - 1
        relative_coords[:, :, 0] *= 2 * self.window_size[1] - 1
        relative_position_index = relative_coords.sum(-1)
        self.register_buffer('relative_position_index', relative_position_index)

        trunc_normal_(self.relative_position_bias_table, std=.02)

        self.softmax = nn.Softmax(dim=-1)
        self.attn_drop = nn.Dropout(attn_drop_rate)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop_rate)

    def forward(self, x, mask=None):
        b, f, c = x.shape
        qkv = self.qkv(x)
        qkv = qkv.reshape(b, f, 3, self.num_heads, c // self.num_heads).permute(2, 0, 3, 1, 4).contiguous()
        q, k, v = qkv[0], qkv[1], qkv[2]

        q = q * self.scale

        attn = (q @ k.transpose(-2, -1).contiguous())

        relative_position_bias = self.relative_position_bias_table[self.relative_position_index.view(-1)]
        relative_position_bias = relative_position_bias.view(self.window_size[0] * self.window_size[1], self.window_size[0] * self.window_size[1], -1)
        relative_position_bias = relative_position_bias.permute(2, 0, 1).contiguous()
        attn = attn + relative_position_bias.unsqueeze(0)

        if mask is not None:
            nt = mask.shape[0]
            attn = attn.view(b // nt, nt, self.num_heads, f, f) + mask.unsqueeze(1).unsqueeze(0)
            attn = attn.view(-1, self.num_heads, f, f)
            attn = self.softmax(attn)
        else:
            attn = self.softmax(attn)

        attn = self.attn_drop(attn)

        x = (attn @ v).transpose(1, 2).contiguous().reshape(b, f, c)
        x = self.proj(x)
        x = self.proj_drop(x)
        return x


class SwinTransformerBlock(nn.Module):
    def __init__(self, dim, input_resolution, num_heads, window_size, shift_size, mlp_ratio,
                 drop_rate=0.):
        super(SwinTransformerBlock, self).__init__()
        self.dim = dim
        self.input_resolution = input_resolution
        self.num_heads = num_heads
        self.window_size = window_size
        self.shift_size = shift_size
        self.mlp_ratio = mlp_ratio
        if min(self.input_resolution) <= self.window_size:
            self.shift_size = 0
            self.window_size = min(self.input_resolution)

        self.norm1 = nn.LayerNorm(dim)
        self.norm2 = nn.LayerNorm(dim)
        self.drop_path = DropPath(drop_rate) if drop_rate > 0. else nn.Identity()
        self.mlp = Mlp(in_features=dim, hidden_features=int(dim * mlp_ratio))

        self.attn = WindowAttention(dim=dim, window_size=to_2tuple(self.window_size), num_heads=num_heads)

        if self.shift_size > 0:
            t, s = self.input_resolution
            img_mask = torch.zeros((1, t, s, 1))
            t_slices = (slice(0, -self.window_size),
                        slice(-self.window_size, -self.shift_size),
                        slice(-self.shift_size, None))
            s_slices = (slice(0, -self.window_size),
                        slice(-self.window_size, -self.shift_size),
                        slice(-self.shift_size, None))

            cnt = 0
            for t_s in t_slices:
                for s_s in s_slices:
                    img_mask[:, t_s, s_s, :] = cnt
                    cnt += 1

            mask_windows = window_partition(img_mask, self.window_size)
            mask_windows = mask_windows.view(-1, self.window_size * self.window_size)
            attn_mask = mask_windows.unsqueeze(1) - mask_windows.unsqueeze(2)
            attn_mask = attn_mask.masked_fill(attn_mask != 0, float(-100.0)).masked_fill(attn_mask == 0, float(0.0))
        else:
            attn_mask = None

        self.register_buffer('attn_mask', attn_mask)

    def forward(self, x):
        t, s = self.input_resolution
        b, f, c = x.shape
        assert f == t * s

        shortcut = x
        x = self.norm1(x)
        x = x.view(b, t, s, c)

        if self.shift_size > 0:
            shifted_x = torch.roll(x, shifts=(-self.shift_size, -self.shift_size), dims=(1, 2))
        else:
            shifted_x = x

        x_windows = window_partition(shifted_x, self.window_size)
        x_windows = x_windows.view(-1, self.window_size * self.window_size, c)

        attn_windows = self.attn(x_windows, mask=self.attn_mask)

        attn_windows = attn_windows.view(-1, self.window_size, self.window_size, c)
        shifted_x = window_reverse(attn_windows, self.window_size, t, s)

        if self.shift_size > 0:
            x = torch.roll(shifted_x, shifts=(self.shift_size, self.shift_size), dims=(1, 2))
        else:
            x = shifted_x

        x = x.view(b, f, c)
        x = shortcut + self.drop_path(x)
        x = x + self.drop_path(self.mlp(self.norm2(x)))
        return x


class BasicLayer(nn.Module):
    def __init__(self, dim, input_resolution, depth, num_heads, window_size, down_sample,
                 mlp_ratio=4.):
        super(BasicLayer, self).__init__()
        self.dim = dim
        self.input_resolution = input_resolution
        self.depth = depth

        self.blocks = nn.ModuleList([
            SwinTransformerBlock(dim=dim, input_resolution=input_resolution,
                                 num_heads=num_heads, window_size=window_size,
                                 shift_size=0 if (i % 2 == 0) else window_size // 2,
                                 mlp_ratio=mlp_ratio)
            for i in range(depth)])

        if down_sample is not None:
            self.down_sample = down_sample(dim=dim, input_resolution=input_resolution)
        else:
            self.down_sample = None

    def forward(self, x):
        b, f, c = x.shape
        for blk in self.blocks:
            x = blk(x)
        if self.down_sample is not None:
            x = self.down_sample(x)
        return x


class BasicLayerUp(nn.Module):
    def __init__(self, dim, input_resolution, depth, num_heads, window_size, up_sample,
                 mlp_ratio=4.):
        super(BasicLayerUp, self).__init__()
        self.dim = dim
        self.input_resolution = input_resolution
        self.depth = depth

        self.blocks = nn.ModuleList([
            SwinTransformerBlock(dim=dim, input_resolution=input_resolution,
                                 num_heads=num_heads, window_size=window_size,
                                 shift_size=0 if (i % 2 == 0) else window_size // 2,
                                 mlp_ratio=mlp_ratio)
            for i in range(depth)])

        if up_sample is not None:
            self.up_sample = up_sample(dim=dim, input_resolution=input_resolution)
        else:
            self.up_sample = None

    def forward(self, x):
        for blk in self.blocks:
            x = blk(x)
        if self.up_sample is not None:
            x = self.up_sample(x)
        return x


class SwinEncoder(nn.Module):
    def __init__(self, in_chans, embed_dim, depths, num_heads, window_size,
                 drop_rate=0.):
        super(SwinEncoder, self).__init__()
        self.patch_embed = PatchEmbed(in_chans=in_chans, embed_dim=embed_dim)
        self.pos_drop = nn.Dropout(p=drop_rate)

        self.num_en_layers = len(depths)
        self.num_features = int(embed_dim * 2 ** (self.num_en_layers - 1))
        self.norm = nn.LayerNorm(self.num_features)
        patches_resolution = [320, 64]
        self.patches_resolution = patches_resolution

        self.layers = nn.ModuleList()
        for i_layer in range(self.num_en_layers):
            if i_layer == 0:
                down_sample = PatchMergingSpatial
            elif i_layer == self.num_en_layers - 1:
                down_sample = None
            else:
                down_sample = PatchMergingSpatioTemporal

            if i_layer == 0:
                input_resolution = (patches_resolution[0], patches_resolution[1])
            else:
                input_resolution = (patches_resolution[0] // (2 ** (i_layer - 1)), patches_resolution[1] // (2 ** i_layer))

            layer = BasicLayer(dim=int(embed_dim * 2 ** i_layer),
                               input_resolution=input_resolution,
                               depth=depths[i_layer], num_heads=num_heads[i_layer],
                               window_size=window_size,
                               down_sample=down_sample)
            self.layers.append(layer)

    def forward(self, x):
        b, c, t, s = x.shape
        x = self.patch_embed(x)
        x = self.pos_drop(x)
        x_down = []

        for layer in self.layers:
            x_down.append(x)
            x = layer(x)
        x = self.norm(x)

        return x, x_down


class SwinDecoder(nn.Module):
    def __init__(self, embed_dim, depths, num_heads, window_size):
        super(SwinDecoder, self).__init__()
        self.num_de_layers = len(depths)
        self.embed_dim = embed_dim

        self.layers_up = nn.ModuleList()
        self.concat_back_dim = nn.ModuleList()

        patches_resolution = [320, 64]
        self.patches_resolution = patches_resolution

        for i_layer in range(self.num_de_layers):
            if i_layer == self.num_de_layers - 1:
                input_resolution = (patches_resolution[0], patches_resolution[1])
            else:
                input_resolution = (patches_resolution[0] // (2 ** (self.num_de_layers - 2 - i_layer)),
                                    patches_resolution[1] // (2 ** (self.num_de_layers - 1 - i_layer)))

            if i_layer == self.num_de_layers - 1:
                up_sample = None
            elif i_layer == self.num_de_layers - 2:
                up_sample = PatchExpandSpatial
            else:
                up_sample = PatchExpandSpatioTemporal

            if i_layer == 0:
                concat_linear = nn.Identity()
                layer_up = PatchExpandSpatioTemporal(dim=int(embed_dim * 2 ** (self.num_de_layers - 1 - i_layer)),
                                                     input_resolution=input_resolution)
            else:
                concat_linear = nn.Linear(2 * int(embed_dim * 2 ** (self.num_de_layers - 1 - i_layer)),
                                          int(embed_dim * 2 ** (self.num_de_layers - 1 - i_layer)))
                layer_up = BasicLayerUp(dim=int(embed_dim * 2 ** (self.num_de_layers - 1 - i_layer)),
                                        input_resolution=input_resolution,
                                        depth=depths[self.num_de_layers - 1 - i_layer],
                                        num_heads=num_heads[self.num_de_layers - 1 - i_layer],
                                        window_size=window_size,
                                        up_sample=up_sample)
            self.layers_up.append(layer_up)
            self.concat_back_dim.append(concat_linear)

        self.norm_up = nn.LayerNorm(embed_dim)

    def forward(self, x, x_down):
        for inx, layer_up in enumerate(self.layers_up):
            if inx == 0:
                x = layer_up(x)
            else:
                x = torch.cat([x, x_down[3 - inx]], -1)
                x = self.concat_back_dim[inx](x)
                x = layer_up(x)

        x = self.norm_up(x)
        return x


class TransLinearProj(nn.Module):
    def __init__(self, embed_dim, out_chans):
        super(TransLinearProj, self).__init__()
        patches_resolution = [320, 64]
        self.patches_resolution = patches_resolution
        self.output = nn.Conv2d(in_channels=embed_dim, out_channels=out_chans, kernel_size=(1, 1), bias=False)

    def forward(self, x):
        t, s = self.patches_resolution
        b, f, c = x.shape
        assert f == t * s

        x = x.view(b, t, s, -1)
        x = x.permute(0, 3, 1, 2).contiguous()
        x = self.output(x)
        return x


class WaveProj(nn.Module):
    def __init__(self, dim, out_chans):
        super(WaveProj, self).__init__()
        self.conv1 = nn.Sequential(
            nn.Conv2d(dim, dim, kernel_size=(3, 3), stride=(1, 1), padding=1),
            nn.BatchNorm2d(dim),
            nn.ReLU(inplace=True))

        self.conv2 = nn.Sequential(
            nn.Conv2d(dim, dim, kernel_size=(3, 3), stride=(1, 1), padding=1),
            nn.BatchNorm2d(dim),
            nn.ReLU(inplace=True))

        self.up1 = nn.Sequential(
            nn.ConvTranspose2d(in_channels=dim, out_channels=dim, kernel_size=(4, 1), stride=(2, 1), padding=(1, 0)),
            nn.BatchNorm2d(dim),
            nn.ELU())

        self.up2 = nn.Sequential(
            nn.ConvTranspose2d(in_channels=dim, out_channels=dim, kernel_size=(4, 1), stride=(2, 1), padding=(1, 0)),
            nn.BatchNorm2d(dim),
            nn.ELU())

        self.poolspa = nn.AdaptiveAvgPool2d((320, 1))

        self.conv3 = nn.Conv2d(dim, out_chans, (1, 1), stride=(1, 1), padding=0)

    def forward(self, x):
        b, f, c = x.shape
        x = x.view(b, f // 8, 8, c)
        x = x.permute(0, 3, 1, 2).contiguous()
        x = self.conv1(x)
        x = self.conv2(x)
        x = self.up1(x)
        x = self.up2(x)
        x = self.poolspa(x)
        x = self.conv3(x)
        x = x.view(-1, 320)
        return x


class SwinUNet(nn.Module):
    def __init__(self, in_chans=3, embed_dim=96, out_chans=1,
                 depths=(2, 2, 2, 2), num_heads=(3, 6, 12, 24), window_size=8):
        super(SwinUNet, self).__init__()
        self.encoder = SwinEncoder(in_chans=in_chans, embed_dim=embed_dim, depths=depths, num_heads=num_heads,
                                   window_size=window_size)
        self.decoder = SwinDecoder(embed_dim=embed_dim, depths=depths, num_heads=num_heads, window_size=window_size)
        self.trans_linear_proj = TransLinearProj(embed_dim=embed_dim, out_chans=out_chans)
        self.wave_proj = WaveProj(dim=embed_dim * 8, out_chans=out_chans)

        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x_face, x_back, x_glob):
        """
        3, 320, 64 --> 96, 320, 64 --> 320*64, 96 --> 320*32, 192 / 160*16, 384 / 80*8, 768 : 640, 768
        """

        x_face_latent, _ = self.encoder(x_face)
        x_back_latent, _ = self.encoder(x_back)
        x_glob_latent, x_down = self.encoder(x_glob)

        b, f, c = x_face_latent.shape
        latent_fine = x_face_latent.transpose(1, 2).contiguous().view(b, c, 8, f // 8)       # b, 768, 8, 80
        latent_coarse = x_back_latent.transpose(1, 2).contiguous().view(b, c, 8, f // 8)     # b, 768, 8, 80

        latent_sim = latent_fine @ latent_coarse.transpose(2, 3).contiguous()   # b, 768, 8, 8
        latent_sim = self.softmax(latent_sim)                                   # b, 768, 8, 8
        latent_noise = latent_sim @ latent_fine                                 # b, 768, 8, 80
        x_fine = latent_fine - latent_noise
        x_fine = x_fine.flatten(2).transpose(1, 2).contiguous()

        x_wave1 = self.wave_proj(x_fine)
        x_wave2 = self.wave_proj(x_face_latent)

        x_map = self.decoder(x_glob_latent, x_down)
        x_map = self.trans_linear_proj(x_map)

        return x_map, x_wave1, x_wave2


