from PIL import Image
import numpy as np
import argparse
import random
import tqdm
import xlrd
import xlwt
import os
import scipy.signal

import torch
from torch import nn
from torch.nn import functional as F
from torch.utils import data
# from torch.utils.data.dataset import T_co
from torchvision import transforms

from einops import rearrange
from timm.models.layers import DropPath, to_2tuple, trunc_normal_


def max_min_norm(x):
    y = (x - np.min(x)) / (np.max(x) - np.min(x))
    return y


class NegPearson(nn.Module):
    def __init__(self):
        super(NegPearson, self).__init__()

    def forward(self, xs, ys):
        loss = 0
        for i in range(xs.shape[0]):
            sum_x = torch.sum(xs[i])
            sum_y = torch.sum(ys[i])
            sum_xy = torch.sum(xs[i] * ys[i])
            sum_x2 = torch.sum(torch.pow(xs[i], 2))
            sum_y2 = torch.sum(torch.pow(ys[i], 2))
            N = ys.shape[1]
            pearson = (N * sum_xy - sum_x * sum_y) / (
                torch.sqrt((N * sum_x2 - torch.pow(sum_x, 2)) * (N * sum_y2 - torch.pow(sum_y, 2))))
            loss += 1 - pearson

        loss = loss / ys.shape[0]
        return loss


class PhysNetST(nn.Module):
    def __init__(self, frames):
        super(PhysNetST, self).__init__()
        self.ConvBlock1 = nn.Sequential(nn.Conv2d(3, 16, (1, 5), stride=1, padding=(0, 2)),
                                        nn.BatchNorm2d(16),
                                        nn.ReLU(inplace=True))

        self.ConvBlock2 = nn.Sequential(nn.Conv2d(16, 32, (3, 3), stride=1, padding=1),
                                        nn.BatchNorm2d(32),
                                        nn.ReLU(inplace=True))

        self.ConvBlock3 = nn.Sequential(nn.Conv2d(32, 64, (3, 3), stride=1, padding=1),
                                        nn.BatchNorm2d(64),
                                        nn.ReLU(inplace=True))

        self.ConvBlock4 = nn.Sequential(nn.Conv2d(64, 64, (3, 3), stride=1, padding=1),
                                        nn.BatchNorm2d(64),
                                        nn.ReLU(inplace=True))

        self.ConvBlock5 = nn.Sequential(nn.Conv2d(64, 64, (3, 3), stride=1, padding=1),
                                        nn.BatchNorm2d(64),
                                        nn.ReLU(inplace=True))

        self.ConvBlock6 = nn.Sequential(nn.Conv2d(64, 64, (3, 3), stride=1, padding=1),
                                        nn.BatchNorm2d(64),
                                        nn.ReLU(inplace=True))

        self.ConvBlock7 = nn.Sequential(nn.Conv2d(64, 64, (3, 3), stride=1, padding=1),
                                        nn.BatchNorm2d(64),
                                        nn.ReLU(inplace=True))

        self.ConvBlock8 = nn.Sequential(nn.Conv2d(64, 64, (3, 3), stride=1, padding=1),
                                        nn.BatchNorm2d(64),
                                        nn.ReLU(inplace=True))

        self.ConvBlock9 = nn.Sequential(nn.Conv2d(64, 64, (3, 3), stride=1, padding=1),
                                        nn.BatchNorm2d(64),
                                        nn.ReLU(inplace=True))

        self.UpSample1 = nn.Sequential(
            nn.ConvTranspose2d(in_channels=64, out_channels=64, kernel_size=(4, 1), stride=(2, 1), padding=(1, 0)),
            nn.BatchNorm2d(64),
            nn.ELU())

        self.UpSample2 = nn.Sequential(
            nn.ConvTranspose2d(in_channels=64, out_channels=64, kernel_size=(4, 1), stride=(2, 1), padding=(1, 0)),
            nn.BatchNorm2d(64),
            nn.ELU())

        self.ConvBlock10 = nn.Conv2d(64, 1, (1, 1), stride=1, padding=0)

        self.MaxpoolSpa = nn.MaxPool2d((1, 2), stride=(1, 2))
        self.MaxpoolSpaTem = nn.MaxPool2d((2, 2), stride=2)

        self.PoolSpa = nn.AdaptiveAvgPool2d((frames, 1))

    def forward(self, x):
        # raw input by our st map: 320 * 64
        b, c, t, s = x.shape
        x = self.ConvBlock1(x)              # 16, t, 64
        x = self.MaxpoolSpa(x)              # 16, t, 32

        x = self.ConvBlock2(x)              # 32, t, 32
        x_visual32 = self.ConvBlock3(x)     # 32, t, 32
        x = self.MaxpoolSpaTem(x_visual32)  # 64, t/2, 16

        x = self.ConvBlock4(x)              # 64, t/2, 16
        x_visual16 = self.ConvBlock5(x)     # 64, t/2, 16
        x = self.MaxpoolSpaTem(x_visual16)  # 64, t/4, 8

        x = self.ConvBlock6(x)              # 64, t/4, 8
        x_visual8 = self.ConvBlock7(x)      # 64, t/4, 8
        x = self.MaxpoolSpa(x_visual8)      # 64, t/4, 4

        x = self.ConvBlock8(x)              # 64, t/4, 4
        x = self.ConvBlock9(x)              # 64, t/4, 4
        x = self.UpSample1(x)               # 64, t/2, 4
        x = self.UpSample2(x)               # 64, t, 4

        x = self.PoolSpa(x)                 # 64, t, 1
        x = self.ConvBlock10(x)             # 1, t, 1

        ppg = x.view(-1, t)

        return ppg


def calculate_heart_rate(wave, top_num, fps):
    wave = max_min_norm(wave)
    wave_top, _ = scipy.signal.find_peaks(wave, distance=10, prominence=(0.5, 1))
    wave_spn = []
    if len(wave_top) >= top_num:
        for i in range(1, len(wave_top)):
            w_spn = wave_top[i] - wave_top[i - 1]
            wave_spn.append(w_spn)
        mean_spn = np.mean(wave_spn)
        hr = 60 * fps / mean_spn
    else:
        hr = 0
    return hr


def CalculateHR(x, fps=25):
    hr_value = []
    shift_num = 50

    segment_size = 100
    top_num = int(segment_size / fps) - 1

    wave = []
    for i in range(len(x)):
        a = float(x[i])
        wave.append(a)

    for i in range((300 - segment_size) // shift_num + 1):
        sub_wave = wave[i * shift_num: i * shift_num + segment_size]
        sub_hr = calculate_heart_rate(sub_wave, top_num=top_num, fps=fps)
        if sub_hr != 0:
            hr_value.append(sub_hr)
    if len(hr_value) != 0:
        out_hr = np.median(hr_value)
    else:
        out_hr = 0
    return out_hr
