import torch
from torch import nn
from torch.nn import functional as F

from .utils import PhysNetST


class PhysiologicalGenerator(nn.Module):
    def __init__(self):
        super(PhysiologicalGenerator, self).__init__()
        self.UpBlock1 = nn.Sequential(
            nn.ConvTranspose2d(in_channels=1, out_channels=64, kernel_size=(1, 4), stride=(1, 2), padding=(0, 1)),
            nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(64),
            nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU())

        self.UpBlock2 = nn.Sequential(
            nn.ConvTranspose2d(in_channels=64, out_channels=128, kernel_size=(1, 4), stride=(1, 2), padding=(0, 1)),
            nn.Conv2d(128, 128, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(128),
            nn.Conv2d(128, 128, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU())

        self.UpBlock3 = nn.Sequential(
            nn.ConvTranspose2d(in_channels=128, out_channels=64, kernel_size=(1, 4), stride=(1, 2), padding=(0, 1)),
            nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(64),
            nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU())

        self.UpBlock4 = nn.Sequential(
            nn.ConvTranspose2d(in_channels=64, out_channels=64, kernel_size=(1, 4), stride=(1, 2), padding=(0, 1)),
            nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(64),
            nn.Conv2d(64, 3, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(3),
            nn.ReLU())

    def forward(self, x):
        b, t = x.shape
        x = x.view(b, 1, t, 1)      # b, 1, t, 1
        x = x.repeat(1, 1, 1, 4)    # b, 1, t, 4

        x = self.UpBlock1(x)    # b, 64, t, 8
        x = self.UpBlock2(x)    # b, 128, t, 16
        x = self.UpBlock3(x)    # b, 64, t, 32
        x = self.UpBlock4(x)    # b, 3, t, 64
        return x


class NoiseGenerator(nn.Module):
    def __init__(self):
        super(NoiseGenerator, self).__init__()

        self.UpBlock1 = nn.Sequential(
            nn.ConvTranspose2d(in_channels=1, out_channels=64, kernel_size=(1, 4), stride=(1, 2), padding=(0, 1)),
            nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(64),
            nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU())

        self.UpBlock2 = nn.Sequential(
            nn.ConvTranspose2d(in_channels=64, out_channels=128, kernel_size=(1, 4), stride=(1, 2), padding=(0, 1)),
            nn.Conv2d(128, 128, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(128),
            nn.Conv2d(128, 128, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU())

        self.UpBlock3 = nn.Sequential(
            nn.ConvTranspose2d(in_channels=128, out_channels=64, kernel_size=(1, 4), stride=(1, 2), padding=(0, 1)),
            nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(64),
            nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU())

        self.UpBlock4 = nn.Sequential(
            nn.ConvTranspose2d(in_channels=64, out_channels=64, kernel_size=(1, 4), stride=(1, 2), padding=(0, 1)),
            nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(64),
            nn.Conv2d(64, 3, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(3),
            nn.ReLU())

    def forward(self, x):
        b, _, t, _ = x.shape    # b, 1, t, 4
        x = self.UpBlock1(x)    # b, 64, t, 8
        x = self.UpBlock2(x)    # b, 128, t, 16
        x = self.UpBlock3(x)    # b, 64, t, 32
        x = self.UpBlock4(x)    # b, 3, t, 64
        return x


class Discriminator(nn.Module):
    def __init__(self):
        super(Discriminator, self).__init__()
        self.ConvBlock1 = nn.Sequential(nn.Conv2d(4, 64, kernel_size=3, stride=1, padding=1),
                                        nn.BatchNorm2d(64),
                                        nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1),
                                        nn.BatchNorm2d(64),
                                        nn.ReLU())

        self.ConvBlock2 = nn.Sequential(nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1),
                                        nn.BatchNorm2d(64),
                                        nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1),
                                        nn.BatchNorm2d(64),
                                        nn.ReLU())

        self.ConvBlock3 = nn.Sequential(nn.Conv2d(64, 128, kernel_size=3, stride=1, padding=1),
                                        nn.BatchNorm2d(128),
                                        nn.Conv2d(128, 128, kernel_size=3, stride=1, padding=1),
                                        nn.BatchNorm2d(128),
                                        nn.ReLU())

        self.ConvBlock4 = nn.Sequential(nn.Conv2d(128, 256, kernel_size=3, stride=1, padding=1),
                                        nn.BatchNorm2d(256),
                                        nn.Conv2d(256, 256, kernel_size=3, stride=1, padding=1),
                                        nn.BatchNorm2d(256),
                                        nn.ReLU())

        self.ConvBlock5 = nn.Sequential(nn.Conv2d(256, 512, kernel_size=3, stride=1, padding=1),
                                        nn.BatchNorm2d(512),
                                        nn.Conv2d(512, 512, kernel_size=3, stride=1, padding=1),
                                        nn.BatchNorm2d(512),
                                        nn.ReLU())

        self.Layer6 = nn.AdaptiveAvgPool2d((1, 1))
        self.Layer7 = nn.Linear(512, 1)

    def forward(self, x_map, x_wave):
        b, c, t, s = x_map.shape

        x_wave = x_wave.view(b, 1, t, 1)
        x_wave = x_wave.repeat(1, 1, 1, 64)     # b, c + 1, t, 64
        x = torch.cat([x_map, x_wave], dim=1)   # b, c + 1, t, 64
        x = self.ConvBlock1(x)
        x = self.ConvBlock2(x)
        x = self.ConvBlock3(x)
        x = self.ConvBlock4(x)
        x = self.ConvBlock5(x)

        x = self.Layer6(x)
        x = x.view(b, -1)
        x = self.Layer7(x)
        x = torch.sigmoid(x)

        return x


class DualGAN(nn.Module):
    def __init__(self, frames):
        super(DualGAN, self).__init__()

        self.BVPEstimator = PhysNetST(frames=frames)
        self.PhysiologicalGenerator = PhysiologicalGenerator()
        self.NoiseGenerator = NoiseGenerator()
        self.Discriminator = Discriminator()

        self.ConvBlock = nn.Sequential(nn.Conv2d(6, 3, kernel_size=3, stride=1, padding=1),
                                       nn.BatchNorm2d(3),
                                       nn.ReLU())

    def forward(self, st_map, gt_wave, noise_wave):
        # raw input by our st map: 320 * 64
        b, c, t, s = st_map.shape

        noise_wave = noise_wave.view(b, 1, t, 1)        # b, 1, t, 1
        noise_wave = noise_wave.repeat(1, 1, 1, 4)      # b, 1, t, 4

        noise_map = self.NoiseGenerator(noise_wave)     # b, 3, t, s
        gt_map = self.PhysiologicalGenerator(gt_wave)   # b, 3, t, s

        synthetics_map = torch.cat([gt_map, noise_map], dim=1)  # b, 6, t, s
        synthetics_map = self.ConvBlock(synthetics_map)         # b, 3, t, s

        reconstruct_wave = self.BVPEstimator(gt_map)              # b, t
        pred_wave = self.BVPEstimator(st_map)           # b, t

        fake_1 = self.Discriminator(st_map, pred_wave)
        fake_2 = self.Discriminator(synthetics_map, gt_wave)
        real_1 = self.Discriminator(st_map, gt_wave)

        return pred_wave, reconstruct_wave, fake_1, fake_2, real_1
