import os
import sys
import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import models


class PPGRegression(nn.Module):
    def __init__(self):
        super(PPGRegression, self).__init__()
        self.ConvBlock1 = nn.Sequential(
            nn.Conv3d(3, 16, (1, 5, 5), stride=1, padding=(0, 2, 2)),
            nn.BatchNorm3d(16),
            nn.ReLU(inplace=True))

        self.ConvBlock2 = nn.Sequential(
            nn.Conv3d(16, 32, (3, 3, 3), stride=1, padding=1),
            nn.BatchNorm3d(32),
            nn.ReLU(inplace=True))

        self.ConvBlock3 = nn.Sequential(
            nn.Conv3d(32, 64, (3, 3, 3), stride=1, padding=1),
            nn.BatchNorm3d(64),
            nn.ReLU(inplace=True))

        self.ConvBlock4 = nn.Sequential(
            nn.Conv3d(64, 64, (3, 3, 3), stride=1, padding=1),
            nn.BatchNorm3d(64),
            nn.ReLU(inplace=True))

        self.ConvBlock5 = nn.Sequential(
            nn.Conv3d(64, 64, (3, 3, 3), stride=1, padding=1),
            nn.BatchNorm3d(64),
            nn.ReLU(inplace=True))

        self.ConvBlock6 = nn.Sequential(
            nn.Conv3d(64, 64, (3, 3, 3), stride=1, padding=1),
            nn.BatchNorm3d(64),
            nn.ReLU(inplace=True))

        self.ConvBlock7 = nn.Sequential(
            nn.Conv3d(64, 64, (3, 3, 3), stride=1, padding=1),
            nn.BatchNorm3d(64),
            nn.ReLU(inplace=True))

        self.MaxpoolSpa = nn.MaxPool3d((1, 2, 2), stride=(1, 2, 2))

    def forward(self, x):
        b, c, t, s = x.shape
        x = F.interpolate(x, size=(t, s**2), mode='bilinear', align_corners=False)
        x = x.view(b, c, t, s, s)

        x = self.ConvBlock1(x)
        x = self.MaxpoolSpa(x)

        x = self.ConvBlock2(x)
        x = self.ConvBlock3(x)
        x = self.MaxpoolSpa(x)

        x = self.ConvBlock4(x)
        x = self.ConvBlock5(x)
        x = self.MaxpoolSpa(x)

        x = self.ConvBlock6(x)
        x = self.ConvBlock7(x)

        return x


class NoiseDisentangle(nn.Module):
    def __init__(self):
        super(NoiseDisentangle, self).__init__()
        self.ConvBlock1 = nn.Sequential(
            nn.Conv2d(64, 128, (3, 3), stride=1, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU())

        self.ConvBlock2 = nn.Sequential(
            nn.Conv2d(128, 128, (3, 3), stride=1, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU())

        self.ConvBlock3 = nn.Sequential(
            nn.Conv2d(128, 64, (3, 3), stride=1, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU())

    def forward(self, x):
        b, c, t, h, w = x.shape
        x = x.view(b, c, t, h * w)
        x = self.ConvBlock1(x)
        x = self.ConvBlock2(x)
        x = self.ConvBlock3(x)
        x = x.view(b, c, t, h, w)
        return x


class SignalEstimator(nn.Module):
    def __init__(self, frames):
        super(SignalEstimator, self).__init__()
        self.ConvBlock1 = nn.Sequential(
            nn.Conv3d(64, 64, (3, 3, 3), stride=1, padding=1),
            nn.BatchNorm3d(64),
            nn.ReLU())

        self.ConvBlock2 = nn.Sequential(
            nn.Conv3d(64, 64, (3, 3, 3), stride=1, padding=1),
            nn.BatchNorm3d(64),
            nn.ReLU())

        self.ConvBlock3 = nn.Sequential(
            nn.Conv3d(64, 64, (3, 3, 3), stride=1, padding=1),
            nn.BatchNorm3d(64),
            nn.ReLU())

        self.ConvBlock4 = nn.Sequential(
            nn.Conv3d(64, 64, (3, 3, 3), stride=1, padding=1),
            nn.BatchNorm3d(64),
            nn.ReLU())

        self.ConvBlock5 = nn.Conv3d(64, 1, (1, 1, 1), stride=1, padding=0)

        self.MaxpoolSpa = nn.MaxPool3d((1, 2, 2), stride=(1, 2, 2))
        self.PoolSpa = nn.AdaptiveAvgPool3d((frames, 1, 1))

    def forward(self, x):
        b, c, t, h, w = x.shape

        x = self.ConvBlock1(x)
        x = self.ConvBlock2(x)
        x = self.MaxpoolSpa(x)

        x = self.ConvBlock3(x)
        x = self.ConvBlock4(x)

        x = self.PoolSpa(x)
        x = self.ConvBlock5(x)

        x = x.view(b, t)
        return x


class Discriminator(nn.Module):
    def __init__(self):
        super(Discriminator, self).__init__()
        self.ConvBlock1 = nn.Sequential(nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1),
                                        nn.BatchNorm2d(64),
                                        nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1),
                                        nn.BatchNorm2d(64),
                                        nn.ReLU())

        self.ConvBlock2 = nn.Sequential(nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1),
                                        nn.BatchNorm2d(64),
                                        nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1),
                                        nn.BatchNorm2d(64),
                                        nn.ReLU())

        self.ConvBlock3 = nn.Sequential(nn.Conv2d(64, 128, kernel_size=3, stride=1, padding=1),
                                        nn.BatchNorm2d(128),
                                        nn.Conv2d(128, 128, kernel_size=3, stride=1, padding=1),
                                        nn.BatchNorm2d(128),
                                        nn.ReLU())

        self.ConvBlock4 = nn.Sequential(nn.Conv2d(128, 256, kernel_size=3, stride=1, padding=1),
                                        nn.BatchNorm2d(256),
                                        nn.Conv2d(256, 256, kernel_size=3, stride=1, padding=1),
                                        nn.BatchNorm2d(256),
                                        nn.ReLU())

        self.ConvBlock5 = nn.Sequential(nn.Conv2d(256, 512, kernel_size=3, stride=1, padding=1),
                                        nn.BatchNorm2d(512),
                                        nn.Conv2d(512, 512, kernel_size=3, stride=1, padding=1),
                                        nn.BatchNorm2d(512),
                                        nn.ReLU())

        self.Layer6 = nn.AdaptiveAvgPool2d((1, 1))
        self.Layer7 = nn.Linear(512, 1)

    def forward(self, x):
        b, c, t, h, w = x.shape

        x = x.view(b, c, t, h * w)

        x = self.ConvBlock1(x)
        x = self.ConvBlock2(x)
        x = self.ConvBlock3(x)
        x = self.ConvBlock4(x)
        x = self.ConvBlock5(x)

        x = self.Layer6(x)
        x = x.view(b, -1)
        x = self.Layer7(x)
        x = torch.sigmoid(x)

        return x


class ND_DeepRPPG(nn.Module):
    def __init__(self, frames):
        super(ND_DeepRPPG, self).__init__()
        self.PPGRegression = PPGRegression()
        self.NoiseDisentangle = NoiseDisentangle()
        self.SignalEstimator = SignalEstimator(frames=frames)
        self.Discriminator = Discriminator()

    def forward(self, x_face, x_back):
        x_raw = self.PPGRegression(x_face)
        x_back = self.PPGRegression(x_back)

        x_noise = self.NoiseDisentangle(x_raw)
        x_back = self.NoiseDisentangle(x_back)

        x_noise_ppg = self.SignalEstimator(x_noise)
        x_back_ppg = self.SignalEstimator(x_back)

        x_phy = x_raw - x_noise
        ppg = self.SignalEstimator(x_phy)

        x_real = self.Discriminator(x_phy)
        x_fake = self.Discriminator(x_noise)

        return ppg, x_noise_ppg, x_back_ppg, x_real, x_fake
