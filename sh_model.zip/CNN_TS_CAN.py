import torch
from torch import nn
from torch.nn import functional as F
from torch.utils import data


class TS_CAN(nn.Module):
    def __init__(self, frames):
        super(TS_CAN, self).__init__()
        self.ConvBlock1 = nn.Sequential(nn.Conv3d(3, 16, (1, 5, 5), stride=1, padding=(0, 2, 2)),
                                        nn.BatchNorm3d(16),
                                        nn.ReLU(inplace=True))

        self.ConvBlock2 = nn.Sequential(nn.Conv3d(16, 32, (3, 3, 3), stride=1, padding=1),
                                        nn.BatchNorm3d(32),
                                        nn.ReLU(inplace=True))

        self.ConvBlock3 = nn.Sequential(nn.Conv3d(32, 64, (3, 3, 3), stride=1, padding=1),
                                        nn.BatchNorm3d(64),
                                        nn.ReLU(inplace=True))

        self.ConvBlock4 = nn.Sequential(nn.Conv3d(64, 64, (3, 3, 3), stride=1, padding=1),
                                        nn.BatchNorm3d(64),
                                        nn.ReLU(inplace=True))

        self.ConvBlock5 = nn.Sequential(nn.Conv3d(64, 64, (3, 3, 3), stride=1, padding=1),
                                        nn.BatchNorm3d(64),
                                        nn.ReLU(inplace=True))

        self.ConvBlock6 = nn.Sequential(nn.Conv3d(64, 64, (3, 3, 3), stride=1, padding=1),
                                        nn.BatchNorm3d(64),
                                        nn.ReLU(inplace=True))

        self.ConvBlock7 = nn.Sequential(nn.Conv3d(64, 64, (3, 3, 3), stride=1, padding=1),
                                        nn.BatchNorm3d(64),
                                        nn.ReLU(inplace=True))

        self.ConvBlock8 = nn.Sequential(nn.Conv3d(64, 64, (3, 3, 3), stride=1, padding=1),
                                        nn.BatchNorm3d(64),
                                        nn.ReLU(inplace=True))

        self.ConvBlock9 = nn.Sequential(nn.Conv3d(64, 64, (3, 3, 3), stride=1, padding=1),
                                        nn.BatchNorm3d(64),
                                        nn.ReLU(inplace=True))

        self.UpSample1 = nn.Sequential(
            nn.ConvTranspose3d(in_channels=64, out_channels=64, kernel_size=(4, 1, 1), stride=(2, 1, 1), padding=(1, 0, 0)),
            nn.BatchNorm3d(64),
            nn.ELU())

        self.UpSample2 = nn.Sequential(
            nn.ConvTranspose3d(in_channels=64, out_channels=64, kernel_size=(4, 1, 1), stride=(2, 1, 1), padding=(1, 0, 0)),
            nn.BatchNorm3d(64),
            nn.ELU())

        self.ConvBlock10 = nn.Conv3d(64, 1, (1, 1, 1), stride=1, padding=0)

        self.MaxpoolSpa = nn.MaxPool3d((1, 2, 2), stride=(1, 2, 2))
        self.MaxpoolSpaTem = nn.MaxPool3d((2, 2, 2), stride=2)

        self.PoolSpa = nn.AdaptiveAvgPool3d((frames, 1, 1))

    def forward(self, x):
        # raw input by our st map: 320 * 64
        b, c, t, s = x.shape

        x_0 = x[:, :, 0, :].view(b, c, 1, s)    # b, c, 1, 64
        x_a = x[:, :, 1:, :]                    # b, c, 319, 64
        x_b = x[:, :, 0:t-1, :]                 # b, c, 319, 64

        x_diff = x_a - x_b                      # b, c, 319, 64
        x = torch.cat((x_0, x_diff), dim=2)     # b, c, 320, 640

        x = F.interpolate(x, size=(t, s**2), mode='bilinear', align_corners=False)

        x = x.view(b, c, t, s, s)           # c, t, 64, 64
        x_visual = x                        # c, t, 64, 64

        x = self.ConvBlock1(x)              # 16, t, 64, 64
        x = self.MaxpoolSpa(x)              # 16, t, 32, 32

        x = self.ConvBlock2(x)              # 32, t, 32, 32
        x_visual32 = self.ConvBlock3(x)     # 32, t, 32, 32
        x = self.MaxpoolSpaTem(x_visual32)  # 64, t/2, 16, 16

        x = self.ConvBlock4(x)              # 64, t/2, 16, 16
        x_visual16 = self.ConvBlock5(x)     # 64, t/2, 16, 16
        x = self.MaxpoolSpaTem(x_visual16)  # 64, t/4, 8, 8

        x = self.ConvBlock6(x)              # 64, t/4, 8, 8
        x_visual8 = self.ConvBlock7(x)      # 64, t/4, 8, 8
        x = self.MaxpoolSpa(x_visual8)      # 64, t/4, 4, 4

        x = self.ConvBlock8(x)              # 64, t/4, 4, 4
        x = self.ConvBlock9(x)              # 64, t/4, 4, 4
        x = self.UpSample1(x)               # 64, t/2, 4, 4
        x = self.UpSample2(x)               # 64, t, 4, 4

        x = self.PoolSpa(x)                 # 64, t, 1, 1
        x = self.ConvBlock10(x)             # 1, t, 1, 1

        ppg = x.view(b, t)

        return ppg
